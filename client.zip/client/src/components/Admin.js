import React from "react"
import Table from "./CarFormTable";
import Form from "./form";

function FormTable(){
    return(
        <>
        <Form/>
        < Table/>
        </>
    )
}
export default FormTable;