import React from 'react'
import "../css/Footer.css"

function Footer() {
  return (
  
    <div className='Box'>
      <h1 style={{ color: "rgb(15, 226, 155)", 
                   textAlign: "center", 
                   marginTop: "-50px",
                   fontSize:"28px" }}>
        ROUTE-MASTER-LTD
      </h1>
     
    </div>

  )
}

export default Footer;



